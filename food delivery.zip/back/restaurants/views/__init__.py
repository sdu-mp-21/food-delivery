from .restaurants import RestaurantViewSet


__all__ = (
    'RestaurantViewSet',
)
